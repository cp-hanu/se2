package tut10.ex3;

public class Main {
    public static void main(String[] args) {

    }
}
