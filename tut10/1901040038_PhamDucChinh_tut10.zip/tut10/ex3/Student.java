package tut10.ex3;

public class Student extends Human{
    private int facultyNum;
    public Student(String firstName, String lastName) {
        super(firstName, lastName);
    }
}
