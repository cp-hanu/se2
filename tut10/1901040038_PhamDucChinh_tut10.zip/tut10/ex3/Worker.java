package tut10.ex3;

public class Worker extends Human  {
    private double salary;
    private byte workingHours;

    public Worker(String firstName, String lastName) {
        super(firstName, lastName);
    }
}
