package tut9.adapter.round;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

/**
 * RoundPegs are compatible with RoundHoles.
 */
@NoArgsConstructor
@AllArgsConstructor
public class RoundPeg {
	//TO-DO: Declare an attribute: name = radius, type = double
	private double radius;
	//TO-DO: Declare the empty constructor

	//TO-DO: Declare another constructor with a parameter

	//TO-DO: Implement getRadius() method
	public double getRadius() {
		return radius;
	}
}
